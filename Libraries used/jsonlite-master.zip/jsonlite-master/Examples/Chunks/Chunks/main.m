//
//  Copyright 2012-2013, Andrii Mamchur
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//  http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License

#import <Foundation/Foundation.h>
#import "JsonLiteObjC/JsonLiteObjC.h"

char chuck1[] = "[\"hello\", nu";
char chuck2[] = "ll, 1234567890]";

int main(int argc, const char * argv[]) {
    @autoreleasepool {        
        JsonLiteParser *parser = [JsonLiteParser parserWithDepth:4];
        JsonLiteAccumulator *acc = [JsonLiteAccumulator accumulatorWithDepth:4];
        parser.delegate = acc;
        NSData *data = [[NSData alloc] initWithBytes:chuck1
                                               length:sizeof(chuck1) - 1];
        [parser parse:data];
        [data release];
        
        data = [[NSData alloc] initWithBytes:chuck2
                                      length:sizeof(chuck2) - 1];
        [parser parse:data];
        [data release];
        
        NSLog(@"Full object - %@", [acc object]);        
    }
    return 0;
}
