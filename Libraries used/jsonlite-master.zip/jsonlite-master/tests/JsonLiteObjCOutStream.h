//
//  JsonLiteObjCOutStream.h
//  JsonLiteObjC
//
//  Created by Andrii Mamchur on 10/25/13.
//  Copyright (c) 2013 Andrii Mamchur. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface JsonLiteObjCOutStream : XCTestCase

@end
