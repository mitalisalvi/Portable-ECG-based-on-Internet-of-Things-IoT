//
//  JsonLiteObjCBase64Tests.h
//  JsonLiteObjC
//
//  Created by Andrii Mamchur on 11/14/13.
//  Copyright (c) 2013 Andrii Mamchur. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface JsonLiteObjCBase64Tests : XCTestCase

@end
